package com.sky.dbup;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DbupApplication {

	public static void main(String[] args) {
		SpringApplication.run(DbupApplication.class, args);
	}

}
